package com.payments.enums;

public enum OD_Enum {
Yes,No;
}
