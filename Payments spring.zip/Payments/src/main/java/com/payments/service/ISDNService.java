package com.payments.service;

import java.util.List;

public interface ISDNService {

	List<String> getnames();

}